#!/usr/bin/env sh

docker build -t ponytang3/poe_2_openai .

docker push ponytang3/poe_2_openai